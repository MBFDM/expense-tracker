<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class ExpenseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }

    public function index(Request $request)
    {
        $query = Expense::where('user_id', $request->user()->id);

        // Filter by category
        if ($request->has('category') && $request->category !== 'all') {
            $query->where('category', $request->category);
        }

        // Search by description
        if ($request->has('search')) {
            $query->where('description', 'ilike', '%' . $request->search . '%');
        }

        // Sort by date (newest first)
        $query->orderBy('date', 'desc');

        // Pagination
        $perPage = $request->get('per_page', 10);
        return $query->paginate($perPage);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:0.01',
            'category' => 'required|in:' . implode(',', Expense::getCategories()),
            'date' => 'required|date',
            'description' => 'nullable|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }

        $expense = Expense::create([
            'user_id' => $request->user()->id,
            'amount' => $request->amount,
            'category' => $request->category,
            'date' => $request->date,
            'description' => $request->description
        ]);

        return response()->json($expense, 201);
    }

    public function show(Request $request, $id)
    {
        $expense = Expense::where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json($expense);
    }

    public function update(Request $request, $id)
    {
        $expense = Expense::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:0.01',
            'category' => 'required|in:' . implode(',', Expense::getCategories()),
            'date' => 'required|date',
            'description' => 'nullable|string|max:255'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'errors' => $validator->errors()
            ], 422);
        }

        $expense->update($request->all());

        return response()->json($expense);
    }

    public function destroy(Request $request, $id)
    {
        $expense = Expense::where('user_id', $request->user()->id)
            ->findOrFail($id);

        $expense->delete();

        return response()->json(['message' => 'Expense deleted successfully']);
    }

    public function totals(Request $request)
    {
        $query = Expense::where('user_id', $request->user()->id);

        if ($request->has('category') && $request->category !== 'all') {
            $query->where('category', $request->category);
        }

        $total = $query->sum('amount');

        return response()->json(['total' => $total]);
    }
}